from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.contrib.auth.models import User
from .models import UserProfile
from exams.models import ExamSession
from django.db.models import Count, Avg, Max, Min

def home(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    return render(request, 'accounts/home.html')

def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        
        if user is not None:
            login(request, user)
            messages.success(request, 'Login successful')
            return redirect('dashboard')
        else:
            messages.error(request, 'Invalid username or password')
    
    return render(request, 'accounts/login.html')

def register(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')
        confirm_password = request.POST.get('confirm_password')
        user_type = request.POST.get('user_type', 'student')
        
        if password != confirm_password:
            messages.error(request, 'Passwords do not match')
            return render(request, 'accounts/register.html')
        
        if User.objects.filter(username=username).exists():
            messages.error(request, 'Username already exists')
            return render(request, 'accounts/register.html')
        
        if User.objects.filter(email=email).exists():
            messages.error(request, 'Email already exists')
            return render(request, 'accounts/register.html')
        
        # Create user
        user = User.objects.create_user(username=username, email=email, password=password)
        
        # Create profile
        UserProfile.objects.create(user=user, user_type=user_type)
        
        messages.success(request, 'Registration successful. Please log in.')
        return redirect('login')
    
    return render(request, 'accounts/register.html')

@login_required
def dashboard(request):
    user = request.user
    profile = UserProfile.objects.get(user=user)
    
    context = {
        'user': user,
        'profile': profile,
    }
    
    if profile.user_type == 'student':
        # For students, show exam statistics
        exam_sessions = ExamSession.objects.filter(student=user)
        completed_exams = exam_sessions.filter(status='completed')
        upcoming_exams = []  # Logic for upcoming exams
        
        context.update({
            'exam_sessions': exam_sessions,
            'completed_exams': completed_exams,
            'upcoming_exams': upcoming_exams,
            'exams_taken': completed_exams.count(),
            'average_score': completed_exams.aggregate(Avg('total_score'))['total_score__avg'],
        })
    
    elif profile.user_type in ['teacher', 'admin']:
        # For teachers, show created exams and student performance
        created_exams = user.created_exams.all()
        exam_sessions = ExamSession.objects.filter(exam__in=created_exams)
        
        context.update({
            'created_exams': created_exams,
            'total_students': User.objects.filter(profile__user_type='student').count(),
            'exam_sessions': exam_sessions,
            'exams_count': created_exams.count(),
        })
    
    return render(request, 'accounts/dashboard.html', context)

@login_required
def profile(request):
    user = request.user
    profile = get_object_or_404(UserProfile, user=user)
    
    context = {
        'user': user,
        'profile': profile,
    }
    
    return render(request, 'accounts/profile.html', context)

@login_required
def edit_profile(request):
    user = request.user
    profile = get_object_or_404(UserProfile, user=user)
    
    if request.method == 'POST':
        user.first_name = request.POST.get('first_name')
        user.last_name = request.POST.get('last_name')
        user.email = request.POST.get('email')
        user.save()
        
        profile.bio = request.POST.get('bio')
        
        if 'profile_picture' in request.FILES:
            profile.profile_picture = request.FILES['profile_picture']
        
        if request.POST.get('date_of_birth'):
            profile.date_of_birth = request.POST.get('date_of_birth')
        
        profile.save()
        
        messages.success(request, 'Profile updated successfully')
        return redirect('profile')
    
    context = {
        'user': user,
        'profile': profile,
    }
    
    return render(request, 'accounts/edit_profile.html', context)