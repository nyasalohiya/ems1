from django import forms
from django.forms import inlineformset_factory
from .models import Exam, Question, Choice, Answer

class ExamForm(forms.ModelForm):
    class Meta:
        model = Exam
        fields = [
            'title', 'course', 'description', 'start_time', 
            'end_time', 'duration_minutes', 'total_marks', 
            'passing_marks', 'is_active'
        ]
        widgets = {
            'start_time': forms.DateTimeInput(attrs={'type': 'datetime-local'}),
            'end_time': forms.DateTimeInput(attrs={'type': 'datetime-local'}),
            'description': forms.Textarea(attrs={'rows': 4}),
        }

class QuestionForm(forms.ModelForm):
    class Meta:
        model = Question
        fields = ['text', 'question_type', 'marks', 'image']
        widgets = {
            'text': forms.Textarea(attrs={'rows': 3}),
        }
    
    def clean(self):
        cleaned_data = super().clean()
        question_type = cleaned_data.get('question_type')
        
        if question_type in ['mcq', 'true_false'] and not self.instance.pk:
            # For new MCQ/True-False questions, we'll handle choices separately
            pass
        
        return cleaned_data

# Creating a formset for choices (multiple choices for MCQ questions)
ChoiceFormSet = inlineformset_factory(
    Question, 
    Choice,
    fields=['text', 'is_correct'],
    extra=4,
    widgets={
        'text': forms.TextInput(attrs={'class': 'form-control'}),
    },
    can_delete=True
)

class AnswerForm(forms.Form):
    choice = forms.ModelChoiceField(
        queryset=Choice.objects.none(),
        widget=forms.RadioSelect,
        required=False
    )
    
    def __init__(self, question, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['choice'].queryset = question.choices.all()

class ShortAnswerForm(forms.Form):
    text_answer = forms.CharField(
        widget=forms.TextInput(attrs={'class': 'form-control'}),
        required=True
    )

class EssayAnswerForm(forms.Form):
    text_answer = forms.CharField(
        widget=forms.Textarea(attrs={'class': 'form-control', 'rows': 5}),
        required=True
    )