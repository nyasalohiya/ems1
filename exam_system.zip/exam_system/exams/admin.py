from django.contrib import admin
from .models import Course, Exam, Question, Choice, ExamSession, Answer

@admin.register(Course)
class CourseAdmin(admin.ModelAdmin):
    list_display = ('code', 'name')
    search_fields = ('code', 'name')

class ChoiceInline(admin.TabularInline):
    model = Choice
    extra = 4

@admin.register(Question)
class QuestionAdmin(admin.ModelAdmin):
    list_display = ('text', 'exam', 'question_type', 'marks', 'order')
    list_filter = ('exam', 'question_type')
    search_fields = ('text', 'exam__title')
    inlines = [ChoiceInline]

@admin.register(Exam)
class ExamAdmin(admin.ModelAdmin):
    list_display = ('title', 'course', 'start_time', 'end_time', 'total_marks', 'is_active')
    list_filter = ('course', 'is_active')
    search_fields = ('title', 'course__name', 'description')
    date_hierarchy = 'start_time'

@admin.register(ExamSession)
class ExamSessionAdmin(admin.ModelAdmin):
    list_display = ('student', 'exam', 'started_at', 'completed_at', 'total_score', 'status')
    list_filter = ('status', 'exam')
    search_fields = ('student__username', 'exam__title')
    date_hierarchy = 'started_at'

@admin.register(Answer)
class AnswerAdmin(admin.ModelAdmin):
    list_display = ('session', 'question', 'marks_obtained')
    list_filter = ('session__exam',)
    search_fields = ('session__student__username', 'question__text')