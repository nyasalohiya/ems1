from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import HttpResponseForbidden
from django.utils import timezone
from django.db.models import Q, Sum, Count, Avg
from django.forms import formset_factory
from .models import Course, Exam, Question, Choice, ExamSession, Answer
from .forms import (
    ExamForm, QuestionForm, ChoiceFormSet, AnswerForm,
    ShortAnswerForm, EssayAnswerForm
)

@login_required
def course_list(request):
    courses = Course.objects.all()
    return render(request, 'exams/course_list.html', {'courses': courses})

@login_required
def course_detail(request, course_id):
    course = get_object_or_404(Course, id=course_id)
    exams = course.exams.all()
    return render(request, 'exams/course_detail.html', {'course': course, 'exams': exams})

@login_required
def exam_list(request):
    user = request.user
    profile = user.profile
    
    if profile.user_type == 'student':
        # For students, show available exams
        now = timezone.now()
        upcoming_exams = Exam.objects.filter(is_active=True, end_time__gt=now)
        past_exams = ExamSession.objects.filter(
            student=user, 
            status='completed'
        ).select_related('exam')
        
        context = {
            'upcoming_exams': upcoming_exams,
            'past_exams': past_exams,
        }
    else:
        # For teachers/admins, show created exams
        exams = Exam.objects.filter(created_by=user)
        context = {'exams': exams}
    
    return render(request, 'exams/exam_list.html', context)

@login_required
def exam_detail(request, exam_id):
    exam = get_object_or_404(Exam, id=exam_id)
    user = request.user
    
    # Check if user is the creator or a student eligible to take the exam
    if user != exam.created_by and user.profile.user_type == 'student':
        # Check if exam is active and within time window
        now = timezone.now()
        if not (exam.is_active and exam.start_time <= now <= exam.end_time):
            messages.error(request, 'This exam is not available at this time.')
            return redirect('exam_list')
    
    # Get existing session if any
    existing_session = ExamSession.objects.filter(
        exam=exam,
        student=user,
    ).order_by('-started_at').first()
    
    context = {
        'exam': exam,
        'existing_session': existing_session,
    }
    
    return render(request, 'exams/exam_detail.html', context)

@login_required
def start_exam(request, exam_id):
    exam = get_object_or_404(Exam, id=exam_id)
    user = request.user
    
    # Verify student can take this exam
    if user.profile.user_type != 'student':
        return HttpResponseForbidden("Only students can take exams")
    
    # Check if exam is active and within time window
    now = timezone.now()
    if not (exam.is_active and exam.start_time <= now <= exam.end_time):
        messages.error(request, 'This exam is not available at this time.')
        return redirect('exam_list')
    
    # Check for existing incomplete sessions
    existing_session = ExamSession.objects.filter(
        exam=exam,
        student=user,
        status='in_progress'
    ).first()
    
    if existing_session:
        # Continue existing session
        return redirect('take_exam', session_id=existing_session.id)
    
    # Create new session
    session = ExamSession.objects.create(
        exam=exam,
        student=user,
        status='in_progress'
    )
    
    return redirect('take_exam', session_id=session.id)

@login_required
def take_exam(request, session_id):
    session = get_object_or_404(ExamSession, id=session_id)
    user = request.user
    
    # Ensure only the student who started the session can access it
    if session.student != user:
        return HttpResponseForbidden("You don't have permission to access this exam session")
    
    # Check if session is already completed
    if session.status == 'completed':
        return redirect('review_exam', session_id=session.id)
    
    # Get all questions for the exam
    questions = session.exam.questions.all().order_by('order')
    
    # Process question answer if submitted
    if request.method == 'POST':
        question_id = request.POST.get('question_id')
        question = get_object_or_404(Question, id=question_id)
        
        # Process answer based on question type
        if question.question_type == 'mcq':
            choice_id = request.POST.get('choice')
            if choice_id:
                choice = get_object_or_404(Choice, id=choice_id)
                Answer.objects.update_or_create(
                    session=session,
                    question=question,
                    defaults={'selected_choice': choice}
                )
        elif question.question_type == 'true_false':
            choice_id = request.POST.get('choice')
            if choice_id:
                choice = get_object_or_404(Choice, id=choice_id)
                Answer.objects.update_or_create(
                    session=session,
                    question=question,
                    defaults={'selected_choice': choice}
                )
        elif question.question_type in ['short_answer', 'essay']:
            text_answer = request.POST.get('text_answer')
            Answer.objects.update_or_create(
                session=session,
                question=question,
                defaults={'text_answer': text_answer}
            )
        
        # Check if "Next" or "Submit" was clicked
        if 'submit_exam' in request.POST:
            return redirect('submit_exam', session_id=session.id)
    
    # Get answered questions
    answered_questions = Answer.objects.filter(session=session).values_list('question_id', flat=True)
    
    context = {
        'session': session,
        'exam': session.exam,
        'questions': questions,
        'answered_questions': answered_questions,
    }
    
    return render(request, 'exams/take_exam.html', context)

@login_required
def submit_exam(request, session_id):
    session = get_object_or_404(ExamSession, id=session_id)
    
    # Ensure only the student who started the session can submit it
    if session.student != request.user:
        return HttpResponseForbidden("You don't have permission to submit this exam")
    
    # Check if session is already completed
    if session.status == 'completed':
        return redirect('review_exam', session_id=session.id)
    
    if request.method == 'POST':
        # Calculate scores for MCQ and True/False questions
        answers = Answer.objects.filter(session=session)
        total_score = 0
        
        for answer in answers:
            question = answer.question
            
            if question.question_type in ['mcq', 'true_false']:
                if answer.selected_choice and answer.selected_choice.is_correct:
                    answer.marks_obtained = question.marks
                else:
                    answer.marks_obtained = 0
            else:
                # For essay/short answers, leave blank for manual grading
                answer.marks_obtained = 0
            
            answer.save()
            total_score += answer.marks_obtained if answer.marks_obtained else 0
        
        # Update session
        session.completed_at = timezone.now()
        session.total_score = total_score
        session.status = 'completed'
        session.save()
        
        messages.success(request, 'Exam submitted successfully!')
        return redirect('review_exam', session_id=session.id)
    
    return render(request, 'exams/submit_exam.html', {'session': session})

@login_required
def review_exam(request, session_id):
    session = get_object_or_404(ExamSession, id=session_id)
    
    # Ensure only the student who took the exam or the creator can review it
    if session.student != request.user and session.exam.created_by != request.user:
        return HttpResponseForbidden("You don't have permission to review this exam")
    
    # Get all answers with questions
    answers = Answer.objects.filter(session=session).select_related('question', 'selected_choice')
    
    context = {
        'session': session,
        'exam': session.exam,
        'answers': answers,
    }
    
    return render(request, 'exams/review_exam.html', context)

# Teacher/Admin views
@login_required
def create_exam(request):
    user = request.user
    
    # Only teachers and admins can create exams
    if user.profile.user_type not in ['teacher', 'admin']:
        return HttpResponseForbidden("Only teachers and admins can create exams")
    
    if request.method == 'POST':
        form = ExamForm(request.POST)
        if form.is_valid():
            exam = form.save(commit=False)
            exam.created_by = user
            exam.save()
            messages.success(request, 'Exam created successfully!')
            return redirect('manage_questions', exam_id=exam.id)
    else:
        form = ExamForm()
    
    return render(request, 'exams/create_exam.html', {'form': form})

@login_required
def edit_exam(request, exam_id):
    exam = get_object_or_404(Exam, id=exam_id)
    
    # Ensure only the creator can edit
    if exam.created_by != request.user:
        return HttpResponseForbidden("You don't have permission to edit this exam")
    
    if request.method == 'POST':
        form = ExamForm(request.POST, instance=exam)
        if form.is_valid():
            form.save()
            messages.success(request, 'Exam updated successfully!')
            return redirect('exam_detail', exam_id=exam.id)
    else:
        form = ExamForm(instance=exam)
    
    return render(request, 'exams/edit_exam.html', {'form': form, 'exam': exam})

@login_required
def manage_questions(request, exam_id):
    exam = get_object_or_404(Exam, id=exam_id)
    
    # Ensure only the creator can manage questions
    if exam.created_by != request.user:
        return HttpResponseForbidden("You don't have permission to manage questions for this exam")
    
    questions = exam.questions.all().order_by('order')
    
    return render(request, 'exams/manage_questions.html', {
        'exam': exam,
        'questions': questions
    })

@login_required
def add_question(request, exam_id):
    exam = get_object_or_404(Exam, id=exam_id)
    
    # Ensure only the creator can add questions
    if exam.created_by != request.user:
        return HttpResponseForbidden("You don't have permission to add questions to this exam")
    
    if request.method == 'POST':
        question_form = QuestionForm(request.POST, request.FILES)
        
        if question_form.is_valid():
            question = question_form.save(commit=False)
            question.exam = exam
            question.order = exam.questions.count() + 1
            question.save()
            
            # If it's an MCQ or True/False, process choices
            if question.question_type in ['mcq', 'true_false']:
                choice_formset = ChoiceFormSet(request.POST, instance=question)
                if choice_formset.is_valid():
                    choice_formset.save()
            
            messages.success(request, 'Question added successfully!')
            return redirect('manage_questions', exam_id=exam.id)
        
        # If form is invalid, prepare choice formset for re-rendering
        if 'question_type' in question_form.cleaned_data:
            if question_form.cleaned_data['question_type'] in ['mcq', 'true_false']:
                choice_formset = ChoiceFormSet(request.POST)
            else:
                choice_formset = None
        else:
            choice_formset = None
    else:
        question_form = QuestionForm()
        choice_formset = None
    
    return render(request, 'exams/add_question.html', {
        'exam': exam,
        'question_form': question_form,
        'choice_formset': choice_formset
    })

@login_required
def edit_question(request, exam_id, question_id):
    exam = get_object_or_404(Exam, id=exam_id)
    question = get_object_or_404(Question, id=question_id, exam=exam)
    
    # Ensure only the creator can edit questions
    if exam.created_by != request.user:
        return HttpResponseForbidden("You don't have permission to edit questions for this exam")
    
    if request.method == 'POST':
        question_form = QuestionForm(request.POST, request.FILES, instance=question)
        
        if question_form.is_valid():
            question = question_form.save()
            
            # If it's an MCQ or True/False, process choices
            if question.question_type in ['mcq', 'true_false']:
                choice_formset = ChoiceFormSet(request.POST, instance=question)
                if choice_formset.is_valid():
                    choice_formset.save()
            
            messages.success(request, 'Question updated successfully!')
            return redirect('manage_questions', exam_id=exam.id)
        
        # If form is invalid, prepare choice formset for re-rendering
        choice_formset = ChoiceFormSet(request.POST, instance=question) if question.question_type in ['mcq', 'true_false'] else None
    else:
        question_form = QuestionForm(instance=question)
        choice_formset = ChoiceFormSet(instance=question) if question.question_type in ['mcq', 'true_false'] else None
    
    return render(request, 'exams/edit_question.html', {
        'exam': exam,
        'question': question,
        'question_form': question_form,
        'choice_formset': choice_formset
    })

@login_required
def delete_question(request, exam_id, question_id):
    exam = get_object_or_404(Exam, id=exam_id)
    question = get_object_or_404(Question, id=question_id, exam=exam)
    
    # Ensure only the creator can delete questions
    if exam.created_by != request.user:
        return HttpResponseForbidden("You don't have permission to delete questions from this exam")
    
    if request.method == 'POST':
        # Delete the question
        question.delete()
        
        # Reorder the remaining questions
        remaining_questions = exam.questions.all().order_by('order')
        for i, q in enumerate(remaining_questions, 1):
            q.order = i
            q.save()
        
        messages.success(request, 'Question deleted successfully!')
        return redirect('manage_questions', exam_id=exam.id)
    
    return render(request, 'exams/delete_question.html', {
        'exam': exam,
        'question': question
    })

@login_required
def exam_results(request, exam_id):
    exam = get_object_or_404(Exam, id=exam_id)
    
    # Ensure only the creator can view results
    if exam.created_by != request.user:
        return HttpResponseForbidden("You don't have permission to view results for this exam")
    
    # Get all completed sessions for this exam
    sessions = ExamSession.objects.filter(
        exam=exam,
        status='completed'
    ).select_related('student')
    
    # Calculate statistics
    stats = {
        'total_students': sessions.count(),
        'average_score': sessions.aggregate(Avg('total_score'))['total_score__avg'] or 0,
        'highest_score': sessions.aggregate(Max('total_score'))['total_score__max'] or 0,
        'lowest_score': sessions.aggregate(Min('total_score'))['total_score__min'] or 0,
        'passing_count': sessions.filter(total_score__gte=exam.passing_marks).count(),
    }
    
    if stats['total_students'] > 0:
        stats['passing_percentage'] = (stats['passing_count'] / stats['total_students']) * 100
    else:
        stats['passing_percentage'] = 0
    
    return render(request, 'exams/exam_results.html', {
        'exam': exam,
        'sessions': sessions,
        'stats': stats
    })