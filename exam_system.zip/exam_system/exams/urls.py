from django.urls import path
from . import views

urlpatterns = [
    # Course URLs
    path('courses/', views.course_list, name='course_list'),
    path('courses/<int:course_id>/', views.course_detail, name='course_detail'),
    
    # Exam URLs
    path('', views.exam_list, name='exam_list'),
    path('<int:exam_id>/', views.exam_detail, name='exam_detail'),
    path('<int:exam_id>/start/', views.start_exam, name='start_exam'),
    path('session/<int:session_id>/', views.take_exam, name='take_exam'),
    path('session/<int:session_id>/submit/', views.submit_exam, name='submit_exam'),
    path('session/<int:session_id>/review/', views.review_exam, name='review_exam'),
    
    # Teacher/Admin URLs
    path('create/', views.create_exam, name='create_exam'),
    path('<int:exam_id>/edit/', views.edit_exam, name='edit_exam'),
    path('<int:exam_id>/questions/', views.manage_questions, name='manage_questions'),
    path('<int:exam_id>/questions/add/', views.add_question, name='add_question'),
    path('<int:exam_id>/questions/<int:question_id>/edit/', views.edit_question, name='edit_question'),
    path('<int:exam_id>/questions/<int:question_id>/delete/', views.delete_question, name='delete_question'),
    path('<int:exam_id>/results/', views.exam_results, name='exam_results'),
]